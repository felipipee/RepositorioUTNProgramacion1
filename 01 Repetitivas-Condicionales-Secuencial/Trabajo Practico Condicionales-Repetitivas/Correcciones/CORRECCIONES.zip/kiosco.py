valor_final = 0.0
valor_con_descuento = 0.0
ahorro = 0.0

print("*" * 30)
print("Bienvenido al kiosco de la facultad")
print("*" * 30)

# Validacion nombre: no vacio y solo letras
nombre = input("Ingrese el nombre del cliente: ")
while len(nombre) < 1 or not nombre.isalpha():
    if len(nombre) < 1:
        print("Error: El nombre no puede estar vacío.")
    else:
        print("Error: El nombre debe contener solo letras.")
    nombre = input("Ingrese el nombre del cliente: ")

print("*" * 30)

# Validacion cantidad con isdigit() antes de convertir
productos_str = input("Ingrese la cantidad de productos a comprar: ")
while not productos_str.isdigit() or int(productos_str) <= 0:
    if not productos_str.isdigit():
        print("Error: La cantidad de productos debe ser un número entero.")
    else:
        print("Error: La cantidad de productos debe ser mayor a cero.")
    productos_str = input("Ingrese la cantidad de productos a comprar: ")
productos_a_comprar = int(productos_str)

print("*" * 30)

precios = []  # solo para guardar cada precio y mostrarlo al final

for i in range(productos_a_comprar):
    # Validacion precio con isdigit() antes de convertir
    precio_str = input(f"Ingrese el precio del producto {i+1}: ")
    while not precio_str.isdigit() or int(precio_str) <= 0:
        if not precio_str.isdigit():
            print("Error: El precio debe ser un número entero.")
        else:
            print("Error: El precio del producto debe ser mayor a cero.")
        precio_str = input(f"Ingrese el precio del producto {i+1}: ")
    precio_producto = float(precio_str)

    valor_final += precio_producto
    precios.append(precio_producto)

    descuento_incluido = input(f"¿El producto {i+1} tiene descuento? (s/n): ").lower()
    while descuento_incluido not in ['s', 'n']:
        print("Error: Debe ingresar 's' para sí o 'n' para no.")
        descuento_incluido = input(f"¿El producto {i+1} tiene descuento? (s/n): ").lower()

    if descuento_incluido == 's':
        precio_con_desc = precio_producto * 0.9
        valor_con_descuento += precio_con_desc
        ahorro += precio_producto - precio_con_desc
    else:
        valor_con_descuento += precio_producto  # sin descuento suma igual

promedio = valor_final / productos_a_comprar

print("*" * 30)
print(f"Nombre del cliente: {nombre}")
print(f"Cantidad de productos comprados: {productos_a_comprar}")
for i in range(productos_a_comprar):
    print(f"Precio del producto {i+1}: ${precios[i]:.2f}")
print(f"Total sin descuentos: ${valor_final:.2f}")
print(f"Total con descuentos: ${valor_con_descuento:.2f}")
print(f"Ahorro: ${ahorro:.2f}")
print(f"Promedio por producto: ${promedio:.2f}")
